<?php
namespace PHPHtmlParser\Exceptions;

/**
 * Class NotLoadedException
 *
 * @package PHPHtmlParser\Exceptions
 */
final class NotLoadedException extends \Exception
{
}
