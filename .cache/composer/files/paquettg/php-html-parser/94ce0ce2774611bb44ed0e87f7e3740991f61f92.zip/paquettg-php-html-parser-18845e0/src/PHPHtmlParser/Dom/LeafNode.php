<?php
namespace PHPHtmlParser\Dom;


/**
 * Class LeafNode
 *
 * @package PHPHtmlParser
 */
abstract class LeafNode extends AbstractNode
{

}