<?php
namespace stringEncode;

class Exception extends \Exception {}
