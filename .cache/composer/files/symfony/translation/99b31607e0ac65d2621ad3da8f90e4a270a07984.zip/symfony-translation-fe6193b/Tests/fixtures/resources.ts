<?xml version="1.0" encoding="utf-8"?>
<TS>
  <context>
    <name>resources</name>
    <message>
      <source>foo</source>
      <translation>bar</translation>
    </message>
    <message>
      <location filename="src/file_1"/>
      <location filename="src/file_2" line="50"/>
      <source>foo_bar</source>
      <translation>foobar</translation>
    </message>
    <message>
      <location filename="src/file_1"/>
      <source>bar_foo</source>
      <translation>barfoo</translation>
    </message>
  </context>
</TS>
