<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

/**
 * @method string classMethod()
 */
class VirtualClass
{
    use VirtualTrait;
}
